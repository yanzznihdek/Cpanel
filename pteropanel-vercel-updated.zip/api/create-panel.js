export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { username, password } = req.body;

  const apiKey = "ptla_wGbaRimow51KoVibBoovWAQ8C6SMgL40Ase7j10FV7t"; // GANTI!
  const apiUrl = "http://trasflok.anti-ddos.me/api/application/users"; // GANTI JUGA

  const payload = {
    username: username,
    email: `${username}@example.com`,
    first_name: username,
    last_name: "User",
    password: password
  };

  try {
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "Accept": "Application/vnd.pterodactyl.v1+json"
      },
      body: JSON.stringify(payload)
    });

    const data = await response.json();
    if (!response.ok) {
      return res.status(response.status).json({ error: data.errors || "Unknown error" });
    }

    return res.status(200).json(data);
  } catch (error) {
    return res.status(500).json({ error: error.toString() });
  }
}